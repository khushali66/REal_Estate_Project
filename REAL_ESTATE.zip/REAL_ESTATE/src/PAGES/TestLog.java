package PAGES;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

public class TestLog {

	public static void main(String[] args) {
//		WebDriver dr = null;
//		Login l;
//		l = new Login(dr);
		//l.do_login("","?Khushi666");
		Logger log=Logger.getLogger("devpinoyLogger");
		log.debug("TC_ID:");
        
	}

}
